#input in the thermal like following

python3 main.py landsd-gncaster.realtime.data.gov.hk 2101 T430_32

# 
# python3 main.py caster port mountpoint
# 
# caster:suppose that the nearby caster is "landsd-gncaster.realtime.data.gov.hk"
#		if you dont have a base station send rtcm stream to your 
#		RTK HAT,please contact the local RTK service appropriate 
#		authority,or make a base station by RTK Base HAT(like as ZED-F9P, LC29H(BS) HAT)
# port: the caster port
# mountpoint: T430_32
#